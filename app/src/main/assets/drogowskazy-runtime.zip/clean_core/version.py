"""Jedyne źródło identyfikacji aktywnej aplikacji."""

APP_NAME = "Drogowskazy"
APP_VERSION = "4.5.12-apk-continuation-20261006"
STAGE = "CURRENT"
DISPLAY_STAGE = "V4.5.12 APK CONTINUATION — autostart / trwała kolejka / bez restartu wykonanych"
